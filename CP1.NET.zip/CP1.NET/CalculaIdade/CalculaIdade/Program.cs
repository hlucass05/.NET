﻿using System;
using System.Globalization;

namespace CalculaIdade
{
    public struct Person
    {
        public string Name { get; }
        public DateTime BirthDate { get; }

        public Person(string name, DateTime birthDate)
        {
            Name = name;
            BirthDate = birthDate;
        }

        public int CalculateAge(DateTime today)
        {
            int age = today.Year - BirthDate.Year;
            if (today < BirthDate.AddYears(age)) age--;
            return age;
        }
    }

    class Program
    {
        static void Main()
        {
            Console.OutputEncoding = System.Text.Encoding.UTF8; 
            Console.WriteLine("=== Calculadora de Idade ===\n");

            Console.Write("Digite o nome completo: ");
            string name = Console.ReadLine()?.Trim() ?? "";

            while (string.IsNullOrWhiteSpace(name))
            {
                Console.Write("Nome inválido. Digite o nome completo: ");
                name = Console.ReadLine()?.Trim() ?? "";
            }

            DateTime birth;
            Console.Write("Digite a data de nascimento (DD/MM/AAAA): ");
            string? input = Console.ReadLine()?.Trim();

            while (true)
            {
                if (!string.IsNullOrWhiteSpace(input))
                {
                    string[] formats = { "dd/MM/yyyy", "d/M/yyyy", "dd-MM-yyyy", "yyyy-MM-dd" };
                    if (DateTime.TryParseExact(input, formats, CultureInfo.InvariantCulture, DateTimeStyles.None, out birth))
                    {
                        break;
                    }

                    if (DateTime.TryParse(input, CultureInfo.GetCultureInfo("pt-BR"), DateTimeStyles.None, out birth) ||
                        DateTime.TryParse(input, out birth))
                    {
                        break;
                    }
                }

                Console.Write("Data inválida. Digite no formato DD/MM/AAAA (ex: 31/12/2000): ");
                input = Console.ReadLine()?.Trim();
            }

            var pessoa = new Person(name, birth);
            DateTime hoje = DateTime.Today;
            int idade = pessoa.CalculateAge(hoje);

            Console.WriteLine("\n--- Resultado ---");
            Console.WriteLine($"Nome: {pessoa.Name}");
            Console.WriteLine($"Data de nascimento: {pessoa.BirthDate:dd/MM/yyyy}");
            Console.WriteLine($"Idade: {idade} anos");

            if (idade >= 18)
                Console.WriteLine("Situação: MAIOR de idade.");
            else
                Console.WriteLine("Situação: MENOR de idade.");

            if (idade >= 18)
                Console.WriteLine("Permissão para CNH: PODE solicitar a Carteira de Habilitação.");
            else
                Console.WriteLine("Permissão para CNH: NÃO pode solicitar (é necessário ter 18 anos).");

            Console.WriteLine("\nPressione qualquer tecla para sair...");
            Console.ReadKey();
        }
    }
}
