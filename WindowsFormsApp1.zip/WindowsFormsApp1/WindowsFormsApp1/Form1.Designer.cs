﻿namespace WindowsFormsApp1
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.OI = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // OI
            // 
            this.OI.AutoSize = true;
            this.OI.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.OI.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.OI.Location = new System.Drawing.Point(338, 198);
            this.OI.Name = "OI";
            this.OI.Size = new System.Drawing.Size(79, 16);
            this.OI.TabIndex = 0;
            this.OI.Text = "Te amo prin";
            this.OI.Click += new System.EventHandler(this.label1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(789, 450);
            this.Controls.Add(this.OI);
            this.Name = "Form1";
            this.Text = "Tranquilo";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label OI;
    }
}

